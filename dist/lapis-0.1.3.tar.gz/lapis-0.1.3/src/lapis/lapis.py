import select
import socket
import asyncio
import pathlib
import runpy
import sys
from threading import Thread
from datetime import datetime
from .server_types import BadRequest, ServerConfig, Request, Response
from http import HTTPMethod

class Lapis:
    s: socket.socket = None
    cfg: ServerConfig = ServerConfig()

    paths: dict = {}

    def __init__(self, config: ServerConfig | None = None):

        if config is not None:
            self.cfg = config

        self.paths = self._bake_paths()

    def run(self, ip: str, port: int):
        self.s = socket.socket()
        self.s.bind((ip, port))
        self.s.listen()
        print(f"Server is now listening on http://{ip}:{port}")

        try:
            while True:
                readable, _, _ = select.select([self.s], [], [], 0.1)
                if self.s in readable:
                    client, _ = self.s.accept()
                    t = Thread(target=self._handle_request, args=(client,), daemon=True)
                    t.start()
        except KeyboardInterrupt:
            pass
        finally:
            self.__close()

    def _get_dynamic_dirs(self, directory: pathlib.Path):
        return [
            p for p in directory.iterdir()
            if p.is_dir() and p.name.startswith("[") and p.name.endswith("]")
        ]

    def _bake_paths(self) -> dict:

        server_path = pathlib.Path(sys.argv[0]).resolve()
        root : pathlib.Path = server_path.parent / pathlib.Path(self.cfg.dir)
        script_file_name = f"{self.cfg.path_script_name}.py"
        result = {}

        for path in root.rglob(script_file_name):
            if not path.is_file():
                continue

            parts = path.relative_to(root).parts
            current_level = result
            current_fs_level = root
            
            for part in parts[:-1]:
                dynamic_dirs = self._get_dynamic_dirs(current_fs_level)
                if len(dynamic_dirs) > 1:
                    raise RuntimeError(
                        f"Multiple dynamic route folders in {current_fs_level}: "
                        f"{', '.join(d.name for d in dynamic_dirs)}"
                    )

                # move filesystem pointer
                current_fs_level = current_fs_level / part

                current_level = current_level.setdefault(part, {})

            script_globals = runpy.run_path(str(path.absolute()))

            # Grab just endpoint methods
            api_routes = {
                f"/{k}": v 
                for k, v in script_globals.items() 
                if k in HTTPMethod
            }

            # Add endpoints
            current_level.update(api_routes)

        return result

    def _handle_request(self, client: socket.socket):
        try:
            data = client.recv(self.cfg.max_request_size)
            current_time = datetime.now().strftime("%H:%M:%S")

            try:
                request = Request(data=data)
            except BadRequest:
                self.__send_response(client, Response(400, "Bad Request"))
                return

            ip, _ = client.getpeername()
            print(f"{current_time} {request.method} {request.base_url} {ip}")

            try:

                path = pathlib.Path(f"{self.cfg.dir}{request.base_url}")
                parts : list[str] = path.relative_to(self.cfg.dir).parts
                
                leaf : dict = self.paths
                for part in parts:
                    if part in leaf:
                        leaf = leaf[part]
                    else:
                        dynamicRoutes: list[str] = list({k: v for k, v in leaf.items() if k.startswith('[') and k.endswith(']')})
                        if len(dynamicRoutes) == 1:
                            request.slugs[dynamicRoutes[0].strip("[]")] = part
                            leaf = leaf[dynamicRoutes[0]]
                        else:
                            raise FileNotFoundError()
                            

                if f"/{request.method}" in leaf:
                    response : Response = asyncio.run(leaf[f"/{request.method}"](request))
                    self.__send_response(client, response)
                else:
                    raise FileNotFoundError()
                
            except FileNotFoundError:
                response : Response = Response(status_code=404, body="404 Not Found")
                self.__send_response(client, response)
                pass

            except Exception as e:
                print(f"Error handling request: {e}")
                response = Response(status_code=500, body="Internal Server Error")
                self.__send_response(client, response)

        except Exception as e:
            print(f"Error handling client: {e}")
            self.__send_response(client, Response(status_code=404, body="404 Not Found"))
            
        finally:
            client.close()

    def __send_response(self, client : socket.socket, response : Response):
        client.sendall(response.to_bytes())
        current_time = datetime.now().strftime("%H:%M:%S")
        peer = client.getpeername()
        ip = peer[0]
        print(f"{current_time} {response.status_code.value} -> {ip}")

    def __close(self):
        if self.s is not None:
            try:
                print("Closing Server...")
                self.s.close()
            except Exception as e:
                print(f"Error when closing socket: {e}")