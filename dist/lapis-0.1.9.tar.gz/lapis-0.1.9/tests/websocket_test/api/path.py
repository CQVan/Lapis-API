from lapis.protocols.websocket import WSPortal


async def WEBSOCKET(portal : WSPortal):

    pass